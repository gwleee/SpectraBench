#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
- 동일 Feature Set과 타깃(label)로 여러 ML 알고리즘을 공정하게 비교
- 분류/회귀를 자동 판별해 적절한 지표를 사용
- 5-fold CV, 고정 시드, 간단 튜닝(기본 합리적 하이퍼파라미터)
- 추론 지연(ms/샘플), 학습 시간(s), 메모리 피크 근사(MB)
- 콜드스타트 성능(n={5,10,20}) 곡선
- 결과: results_metrics.csv, coldstart_metrics.csv, table_ml_algorithms.tex
"""

import argparse
import time
import os
import sys
import json
import math
import psutil
import numpy as np
import pandas as pd
from pathlib import Path
from typing import Tuple, Dict, Any, List

from sklearn.model_selection import StratifiedKFold, KFold
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.metrics import (
    accuracy_score, balanced_accuracy_score, f1_score, roc_auc_score,
    mean_absolute_error, mean_squared_error, r2_score
)
from sklearn.utils.multiclass import type_of_target

from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor, GradientBoostingClassifier, GradientBoostingRegressor
from sklearn.neural_network import MLPClassifier, MLPRegressor
from sklearn.svm import SVC, SVR
from sklearn.linear_model import LogisticRegression, LinearRegression

# Optional: XGBoost
try:
    from xgboost import XGBClassifier, XGBRegressor
    XGB_AVAILABLE = True
except Exception:
    XGB_AVAILABLE = False


SEED = 42
np.random.seed(SEED)


def infer_problem_type(y: pd.Series) -> str:
    t = type_of_target(y)
    # 'binary', 'multiclass', 'multilabel-indicator', 'continuous', ...
    if t in ("binary", "multiclass"):
        return "classification"
    elif t in ("continuous", "continuous-multioutput"):
        return "regression"
    # try to coerce: if unique values <= 20 and are ints -> classification
    unique_vals = y.dropna().unique()
    if pd.api.types.is_integer_dtype(y) and len(unique_vals) <= 20:
        return "classification"
    # fallback
    return "regression"


def build_preprocessor(X: pd.DataFrame, scale_numeric: bool = True) -> Tuple[ColumnTransformer, List[str], List[str]]:
    cat_cols = [c for c in X.columns if pd.api.types.is_object_dtype(X[c]) or pd.api.types.is_categorical_dtype(X[c])]
    num_cols = [c for c in X.columns if c not in cat_cols]
    transformers = []
    if cat_cols:
        transformers.append(("cat", OneHotEncoder(handle_unknown="ignore"), cat_cols))
    if num_cols:
        if scale_numeric:
            transformers.append(("num", StandardScaler(), num_cols))
        else:
            transformers.append(("num", "passthrough", num_cols))
    preproc = ColumnTransformer(transformers, remainder="drop", sparse_threshold=0.3)
    return preproc, num_cols, cat_cols


def build_models(problem: str) -> Dict[str, Any]:
    models = {}

    if problem == "classification":
        models.update({
            "RandomForest": RandomForestClassifier(
                n_estimators=200, max_depth=None, n_jobs=-1, random_state=SEED
            ),
            "GradientBoosting": GradientBoostingClassifier(random_state=SEED),
            "SVM_RBF": SVC(kernel="rbf", probability=True, random_state=SEED),
            "NeuralNetwork": MLPClassifier(hidden_layer_sizes=(128, 64), max_iter=300, random_state=SEED),
            "LogisticRegression": LogisticRegression(max_iter=200, n_jobs=-1, random_state=SEED)
        })
        if XGB_AVAILABLE:
            models["XGBoost"] = XGBClassifier(
                n_estimators=300, learning_rate=0.05, max_depth=8,
                subsample=0.9, colsample_bytree=0.8, reg_lambda=1.0,
                objective="binary:logistic", eval_metric="logloss", random_state=SEED,
                n_jobs=-1
            )
    else:
        models.update({
            "RandomForest": RandomForestRegressor(
                n_estimators=300, max_depth=None, n_jobs=-1, random_state=SEED
            ),
            "GradientBoosting": GradientBoostingRegressor(random_state=SEED),
            "SVM_RBF": SVR(kernel="rbf"),
            "NeuralNetwork": MLPRegressor(hidden_layer_sizes=(128, 64), max_iter=400, random_state=SEED),
            "LinearRegression": LinearRegression(n_jobs=None if sys.platform=="darwin" else -1)
        })
        if XGB_AVAILABLE:
            models["XGBoost"] = XGBRegressor(
                n_estimators=400, learning_rate=0.05, max_depth=8,
                subsample=0.9, colsample_bytree=0.8, reg_lambda=1.0,
                objective="reg:squarederror", random_state=SEED,
                n_jobs=-1
            )
    return models


def measure_peak_mem_mb() -> float:
    process = psutil.Process(os.getpid())
    mem = process.memory_info().rss / (1024 ** 2)  # MB
    return mem


def predict_latency_ms(model, X_test, reps: int = 3) -> float:
    # warmup
    _ = model.predict(X_test[:3])
    start = time.perf_counter()
    for _ in range(reps):
        _ = model.predict(X_test)
    total = time.perf_counter() - start
    per_sample_ms = (total / (reps * len(X_test))) * 1000.0
    return per_sample_ms


def eval_cv_classification(pipe, X, y, n_splits=5) -> Dict[str, float]:
    skf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=SEED)
    accs, baccs, f1s, aucs = [], [], [], []
    train_secs = []
    lat_ms = []
    mem_peaks = []

    for tr, te in skf.split(X, y):
        X_tr, X_te = X.iloc[tr], X.iloc[te]
        y_tr, y_te = y.iloc[tr], y.iloc[te]

        mem_before = measure_peak_mem_mb()
        t0 = time.perf_counter()
        pipe.fit(X_tr, y_tr)
        train_time = time.perf_counter() - t0
        mem_after = measure_peak_mem_mb()

        y_hat = pipe.predict(X_te)
        try:
            proba = pipe.predict_proba(X_te)[:, 1] if len(np.unique(y)) == 2 else None
        except Exception:
            proba = None

        train_secs.append(train_time)
        accs.append(accuracy_score(y_te, y_hat))
        baccs.append(balanced_accuracy_score(y_te, y_hat))
        f1s.append(f1_score(y_te, y_hat, average="macro"))

        if proba is not None:
            try:
                aucs.append(roc_auc_score(y_te, proba))
            except Exception:
                pass

        lat_ms.append(predict_latency_ms(pipe, X_te))
        mem_peaks.append(max(mem_before, mem_after))

    out = {
        "accuracy": float(np.mean(accs)),
        "balanced_accuracy": float(np.mean(baccs)),
        "f1_macro": float(np.mean(f1s)),
        "auc": float(np.mean(aucs)) if aucs else np.nan,
        "train_time_s": float(np.mean(train_secs)),
        "pred_latency_ms": float(np.mean(lat_ms)),
        "peak_mem_mb": float(np.max(mem_peaks)),
    }
    return out


def eval_cv_regression(pipe, X, y, n_splits=5) -> Dict[str, float]:
    kf = KFold(n_splits=n_splits, shuffle=True, random_state=SEED)
    maes, rmses, r2s = [], [], []
    train_secs = []
    lat_ms = []
    mem_peaks = []

    for tr, te in kf.split(X, y):
        X_tr, X_te = X.iloc[tr], X.iloc[te]
        y_tr, y_te = y.iloc[tr], y.iloc[te]

        mem_before = measure_peak_mem_mb()
        t0 = time.perf_counter()
        pipe.fit(X_tr, y_tr)
        train_time = time.perf_counter() - t0
        mem_after = measure_peak_mem_mb()

        y_hat = pipe.predict(X_te)
        train_secs.append(train_time)
        maes.append(mean_absolute_error(y_te, y_hat))
        rmses.append(math.sqrt(mean_squared_error(y_te, y_hat)))
        r2s.append(r2_score(y_te, y_hat))

        lat_ms.append(predict_latency_ms(pipe, X_te))
        mem_peaks.append(max(mem_before, mem_after))

    out = {
        "mae": float(np.mean(maes)),
        "rmse": float(np.mean(rmses)),
        "r2": float(np.mean(r2s)),
        "train_time_s": float(np.mean(train_secs)),
        "pred_latency_ms": float(np.mean(lat_ms)),
        "peak_mem_mb": float(np.max(mem_peaks)),
    }
    return out


def eval_coldstart(pipe, X, y, problem: str, sizes=(5,10,20)) -> Dict[str, Dict[str, float]]:
    # 단일 홀드아웃(20%)에서 작은 학습 샘플 크기별 성능 측정
    # 분류: balanced_accuracy, 회귀: MAE
    from sklearn.model_selection import train_test_split
    X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.2, random_state=SEED, stratify=y if problem=="classification" else None)

    metrics = {}
    for n in sizes:
        n = min(n, len(X_tr))
        pipe_ = Pipeline(pipe.steps)  # clone-like
        t0 = time.perf_counter()
        pipe_.fit(X_tr.iloc[:n], y_tr.iloc[:n])
        _ = time.perf_counter() - t0

        y_hat = pipe_.predict(X_te)
        if problem == "classification":
            metrics[str(n)] = {
                "balanced_accuracy": float(balanced_accuracy_score(y_te, y_hat)),
                "f1_macro": float(f1_score(y_te, y_hat, average="macro"))
            }
        else:
            metrics[str(n)] = {
                "mae": float(mean_absolute_error(y_te, y_hat)),
                "r2": float(r2_score(y_te, y_hat))
            }
    return metrics


def to_latex_table(problem: str, df: pd.DataFrame, out_path: Path):
    """
    논문 표용 LaTeX 생성 (이론 복잡도 열 + 실험 열)
    """
    # 복잡도 사전(필요 시 수정)
    complexity = {
        "RandomForest": ("$O(T\\,n\\log n)$", "$O(T\\log n)$", "Low", "High", "Excellent"),
        "XGBoost": ("$O(T\\,n\\log n)$", "$O(T\\log n)$", "Medium", "Medium", "Good"),
        "NeuralNetwork": ("$O(n^2\\,E)$", "$O(H\\,L)$", "High", "Low", "Poor"),
        "SVM_RBF": ("$O(n^3)$", "$O(n_{sv})$", "Low", "Low", "Good"),
        "LinearRegression": ("$O(n\\,f^2)$", "$O(f)$", "Very Low", "High", "Fair"),
        "LogisticRegression": ("$O(n\\,f^2)$", "$O(f)$", "Very Low", "High", "Good"),
        "GradientBoosting": ("$O(T\\,n\\log n)$", "$O(T\\log n)$", "Medium", "Medium", "Good")
    }

    lines = []
    lines.append("\\begin{table}[t!]")
    lines.append("\\centering")
    lines.append("\\caption{Algorithm comparison: theoretical properties vs. empirical results}")
    lines.append("\\label{tab:algo_comparison_empirical}")
    lines.append("\\scriptsize")
    lines.append("\\setlength{\\tabcolsep}{4pt}")
    if problem == "classification":
        lines.append("\\begin{tabular}{lcccccccc}")
        lines.append("\\toprule")
        lines.append("\\textbf{Algorithm} & \\textbf{Train Comp.} & \\textbf{Pred. Comp.} & \\textbf{Mem.} & \\textbf{Interp.} & \\textbf{Cold-Start} & \\textbf{BAcc} & \\textbf{F1$_{macro}$} & \\textbf{Latency (ms)} \\\\")
        lines.append("\\midrule")
        for _, r in df.iterrows():
            alg = r["algorithm"]
            tc, pc, mem, interp, cs = complexity.get(alg, ("-", "-", "-", "-", "-"))
            lines.append(f"{alg} & {tc} & {pc} & {mem} & {interp} & {cs} & "
                         f"{r['balanced_accuracy']*100:.2f}\\% & {r['f1_macro']*100:.2f}\\% & {r['pred_latency_ms']:.3f} \\\\")
    else:
        lines.append("\\begin{tabular}{lcccccccc}")
        lines.append("\\toprule")
        lines.append("\\textbf{Algorithm} & \\textbf{Train Comp.} & \\textbf{Pred. Comp.} & \\textbf{Mem.} & \\textbf{Interp.} & \\textbf{Cold-Start} & \\textbf{MAE} & \\textbf{RMSE} & \\textbf{Latency (ms)} \\\\")
        lines.append("\\midrule")
        for _, r in df.iterrows():
            alg = r["algorithm"]
            tc, pc, mem, interp, cs = complexity.get(alg, ("-", "-", "-", "-", "-"))
            lines.append(f"{alg} & {tc} & {pc} & {mem} & {interp} & {cs} & "
                         f"{r['mae']:.4f} & {r['rmse']:.4f} & {r['pred_latency_ms']:.3f} \\\\")
    lines.append("\\bottomrule")
    lines.append("\\end{tabular}")
    lines.append("\\end{table}")

    out_path.write_text("\n".join(lines), encoding="utf-8")


def main():
    parser = argparse.ArgumentParser(description="Compare ML algorithms on the same SpectraBench feature set.")
    parser.add_argument("--data", type=str, required=True, help="CSV 파일 경로 (feature + target 포함)")
    parser.add_argument("--target", type=str, required=True, help="타깃 컬럼명")
    parser.add_argument("--output_dir", type=str, default="results_ml_compare", help="결과 저장 폴더")
    parser.add_argument("--scale_numeric", action="store_true", help="숫자형 스케일링 여부(기본은 비활성). SVM/NN에는 유리")
    parser.add_argument("--folds", type=int, default=5, help="교차검증 폴드 수")
    args = parser.parse_args()

    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    df = pd.read_csv(args.data)
    if args.target not in df.columns:
        print(f"[ERROR] target '{args.target}' not in columns: {df.columns.tolist()}")
        sys.exit(1)

    y = df[args.target]
    X = df.drop(columns=[args.target])

    problem = infer_problem_type(y)
    print(f"[INFO] Detected problem type: {problem}")

    preproc, num_cols, cat_cols = build_preprocessor(X, scale_numeric=args.scale_numeric)
    models = build_models(problem)

    rows = []
    cold_rows = []
    for name, model in models.items():
        print(f"[INFO] Evaluating: {name}")

        pipe = Pipeline(steps=[
            ("preprocess", preproc),
            ("model", model)
        ])

        if problem == "classification":
            metrics = eval_cv_classification(pipe, X, y, n_splits=args.folds)
            row = {
                "algorithm": name,
                **metrics
            }
            rows.append(row)
            # cold-start
            cs = eval_coldstart(pipe, X, y, problem=problem, sizes=(5,10,20))
            for n, vals in cs.items():
                cold_rows.append({"algorithm": name, "n_train": int(n), **vals})
        else:
            metrics = eval_cv_regression(pipe, X, y, n_splits=args.folds)
            row = {
                "algorithm": name,
                **metrics
            }
            rows.append(row)
            cs = eval_coldstart(pipe, X, y, problem=problem, sizes=(5,10,20))
            for n, vals in cs.items():
                cold_rows.append({"algorithm": name, "n_train": int(n), **vals})

    res_df = pd.DataFrame(rows).sort_values(by=list(rows[0].keys())[1:], ascending=[False]+[True]*(len(rows[0].keys())-2) if problem=="classification" else False)
    cold_df = pd.DataFrame(cold_rows).sort_values(["algorithm","n_train"])

    res_csv = out_dir / "results_metrics.csv"
    cold_csv = out_dir / "coldstart_metrics.csv"
    res_df.to_csv(res_csv, index=False)
    cold_df.to_csv(cold_csv, index=False)
    print(f"[INFO] Saved: {res_csv}")
    print(f"[INFO] Saved: {cold_csv}")

    tex_path = out_dir / "table_ml_algorithms.tex"
    to_latex_table(problem, res_df, tex_path)
    print(f"[INFO] Saved LaTeX table: {tex_path}")

    # 콘솔 요약
    if problem == "classification":
        show_cols = ["algorithm", "balanced_accuracy", "f1_macro", "train_time_s", "pred_latency_ms", "peak_mem_mb"]
    else:
        show_cols = ["algorithm", "mae", "rmse", "r2", "train_time_s", "pred_latency_ms", "peak_mem_mb"]
    print("\n=== Summary ===")
    print(res_df[show_cols].to_string(index=False))


if __name__ == "__main__":
    main()
